package kr.co.mountaintouchlog;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {

    static class Event {
        String type;
        long time;
        double lat = Double.NaN;
        double lon = Double.NaN;
        double alt = Double.NaN;
        String note = "";

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("time", time);
            o.put("lat", lat);
            o.put("lon", lon);
            o.put("alt", alt);
            o.put("note", note);
            return o;
        }

        static Event fromJson(JSONObject o) throws Exception {
            Event e = new Event();
            e.type = o.getString("type");
            e.time = o.getLong("time");
            e.lat = o.optDouble("lat", Double.NaN);
            e.lon = o.optDouble("lon", Double.NaN);
            e.alt = o.optDouble("alt", Double.NaN);
            e.note = o.optString("note", "");
            return e;
        }
    }

    private final ArrayList<Event> events = new ArrayList<>();
    private LinearLayout eventContainer;
    private TextView statusText, reportText;
    private LocationManager locationManager;
    private Location lastLocation;
    private Location lastTransportLocation;
    private boolean trackingTransport = false;
    private float transportDistanceMeters = 0f;

    private final SimpleDateFormat timeFmt =
            new SimpleDateFormat("HH:mm:ss", Locale.KOREA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventContainer = findViewById(R.id.eventContainer);
        statusText = findViewById(R.id.statusText);
        reportText = findViewById(R.id.reportText);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        findViewById(R.id.contactButton).setOnClickListener(v ->
                addMainEvent("환자접촉", false));
        findViewById(R.id.treatmentButton).setOnClickListener(v ->
                addTreatment());
        findViewById(R.id.transportButton).setOnClickListener(v -> {
            if (addMainEvent("이송시작", false)) startTransportTracking();
        });
        findViewById(R.id.descentButton).setOnClickListener(v -> {
            if (addMainEvent("하산완료", false)) stopTransportTracking();
        });

        findViewById(R.id.fireButton).setOnClickListener(v ->
                addMainEvent("소방 인계", true));
        findViewById(R.id.heliButton).setOnClickListener(v ->
                addMainEvent("헬기 인계", true));
        findViewById(R.id.hospitalButton).setOnClickListener(v ->
                addMainEvent("병원 이송", true));

        findViewById(R.id.reportButton).setOnClickListener(v -> buildReport());
        findViewById(R.id.copyButton).setOnClickListener(v -> copyReport());
        findViewById(R.id.resetButton).setOnClickListener(v -> confirmReset());

        requestLocationPermission();
        loadState();
        renderTimeline();

        if (findFirst("이송시작") != null && findFirst("하산완료") == null) {
            startTransportTracking();
        }
    }

    private void requestLocationPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, 2001);
        } else {
            startLocationUpdates();
        }
    }

    private void startLocationUpdates() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) return;

            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 3000, 3, this);

            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (gps != null) lastLocation = gps;
        } catch (Exception ignored) {}
    }

    private boolean addMainEvent(String type, boolean allowDuplicate) {
        if (!allowDuplicate && findFirst(type) != null) {
            Toast.makeText(this, type + " 기록이 이미 있습니다.", Toast.LENGTH_SHORT).show();
            return false;
        }

        Event e = new Event();
        e.type = type;
        e.time = System.currentTimeMillis();
        applyCurrentLocation(e);
        events.add(e);
        saveState();
        renderTimeline();

        statusText.setText(type + " 기록 완료 · " + timeFmt.format(new Date(e.time)));
        return true;
    }

    private void addTreatment() {
        final EditText input = new EditText(this);
        input.setHint("예: 우측 발목 부목 고정, 산소 4L 적용");

        new AlertDialog.Builder(this)
                .setTitle("처치 기록")
                .setView(input)
                .setPositiveButton("기록", (d, w) -> {
                    Event e = new Event();
                    e.type = "처치";
                    e.time = System.currentTimeMillis();
                    e.note = input.getText().toString().trim();
                    applyCurrentLocation(e);
                    events.add(e);
                    saveState();
                    renderTimeline();
                    statusText.setText("처치 기록 완료 · " + timeFmt.format(new Date(e.time)));
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void applyCurrentLocation(Event e) {
        Location l = lastLocation;
        if (l != null) {
            e.lat = l.getLatitude();
            e.lon = l.getLongitude();
            if (l.hasAltitude()) e.alt = l.getAltitude();
        }
    }

    private void renderTimeline() {
        eventContainer.removeAllViews();

        if (events.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("\n아직 기록이 없습니다.");
            eventContainer.addView(empty);
            return;
        }

        for (int i = 0; i < events.size(); i++) {
            final int idx = i;
            Event e = events.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 8, 0, 8);

            TextView t = new TextView(this);
            t.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            t.setText(formatEvent(e));
            t.setTextSize(14);

            Button edit = new Button(this);
            edit.setText("수정");
            edit.setOnClickListener(v -> editEvent(idx));

            Button del = new Button(this);
            del.setText("삭제");
            del.setOnClickListener(v -> deleteEvent(idx));

            row.addView(t);
            row.addView(edit);
            row.addView(del);
            eventContainer.addView(row);
        }
    }

    private String formatEvent(Event e) {
        StringBuilder sb = new StringBuilder();
        sb.append(timeFmt.format(new Date(e.time))).append("  ").append(e.type);
        if (!e.note.isEmpty()) sb.append("\n").append(e.note);
        if (!Double.isNaN(e.lat)) {
            sb.append(String.format(Locale.KOREA,
                    "\nGPS %.5f, %.5f", e.lat, e.lon));
        }
        if (!Double.isNaN(e.alt)) {
            sb.append(String.format(Locale.KOREA, " · 고도 %.0fm", e.alt));
        }
        return sb.toString();
    }

    private void editEvent(int idx) {
        Event e = events.get(idx);
        final EditText input = new EditText(this);
        input.setText(e.note);
        input.setHint("메모 수정");

        new AlertDialog.Builder(this)
                .setTitle(e.type + " 메모 수정")
                .setView(input)
                .setPositiveButton("저장", (d, w) -> {
                    e.note = input.getText().toString().trim();
                    saveState();
                    renderTimeline();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void deleteEvent(int idx) {
        Event e = events.get(idx);
        new AlertDialog.Builder(this)
                .setTitle("기록 삭제")
                .setMessage(timeFmt.format(new Date(e.time)) + " " + e.type + " 기록을 삭제할까요?")
                .setPositiveButton("삭제", (d, w) -> {
                    events.remove(idx);
                    if ("이송시작".equals(e.type) || "하산완료".equals(e.type)) {
                        recalcTransportState();
                    }
                    saveState();
                    renderTimeline();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void startTransportTracking() {
        trackingTransport = true;
        lastTransportLocation = lastLocation;
        statusText.setText("이송 중 · GPS 이동거리 누적 중");
        saveState();
    }

    private void stopTransportTracking() {
        trackingTransport = false;
        lastTransportLocation = null;
        statusText.setText("하산완료 · 이송거리 "
                + String.format(Locale.KOREA, "%.2f km", transportDistanceMeters / 1000f));
        saveState();
    }

    private void recalcTransportState() {
        Event start = findFirst("이송시작");
        Event end = findFirst("하산완료");
        trackingTransport = start != null && end == null;
        if (start == null) transportDistanceMeters = 0f;
        lastTransportLocation = trackingTransport ? lastLocation : null;
    }

    private Event findFirst(String type) {
        for (Event e : events) {
            if (type.equals(e.type)) return e;
        }
        return null;
    }

    private ArrayList<Event> findAll(String type) {
        ArrayList<Event> out = new ArrayList<>();
        for (Event e : events) if (type.equals(e.type)) out.add(e);
        return out;
    }

    private void buildReport() {
        Event contact = findFirst("환자접촉");
        Event start = findFirst("이송시작");
        Event descent = findFirst("하산완료");
        ArrayList<Event> treatments = findAll("처치");

        StringBuilder s = new StringBuilder();

        if (contact != null) {
            s.append(timeFmt.format(new Date(contact.time)))
                    .append(" 요구조자 접촉.");
        }

        for (Event e : treatments) {
            s.append(" ").append(timeFmt.format(new Date(e.time)))
                    .append(" 응급처치 실시");
            if (!e.note.isEmpty()) s.append("(").append(e.note).append(")");
            s.append(".");
        }

        if (start != null) {
            s.append(" ").append(timeFmt.format(new Date(start.time)))
                    .append(" 이송 시작.");
        }

        if (descent != null) {
            s.append(" ").append(timeFmt.format(new Date(descent.time)))
                    .append(" 하산 완료.");
        }

        for (Event e : events) {
            if ("소방 인계".equals(e.type) || "헬기 인계".equals(e.type)
                    || "병원 이송".equals(e.type)) {
                s.append(" ").append(timeFmt.format(new Date(e.time)))
                        .append(" ").append(e.type).append(".");
            }
        }

        s.append("\n\n[자동 계산]");
        if (contact != null && descent != null) {
            s.append("\n총 활동시간: ").append(formatDuration(descent.time - contact.time));
        }
        if (contact != null && !treatments.isEmpty()) {
            s.append("\n환자접촉→첫 처치: ")
                    .append(formatDuration(treatments.get(0).time - contact.time));
        }
        if (start != null && descent != null) {
            s.append("\n이송 소요시간: ")
                    .append(formatDuration(descent.time - start.time));
        }
        if (transportDistanceMeters > 0) {
            s.append(String.format(Locale.KOREA,
                    "\nGPS 누적 이송거리: %.2f km", transportDistanceMeters / 1000f));
        }
        if (start != null && descent != null
                && !Double.isNaN(start.alt) && !Double.isNaN(descent.alt)) {
            s.append(String.format(Locale.KOREA,
                    "\n이송 시작→하산완료 고도차: %.0f m", descent.alt - start.alt));
        }

        reportText.setText(s.length() > 0 ? s.toString()
                : "기록된 활동이 없습니다.");
    }

    private String formatDuration(long ms) {
        long sec = Math.max(0, ms / 1000);
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long ss = sec % 60;
        if (h > 0) return String.format(Locale.KOREA, "%d시간 %d분 %d초", h, m, ss);
        return String.format(Locale.KOREA, "%d분 %d초", m, ss);
    }

    private void copyReport() {
        ClipboardManager cm =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(
                "산악구조 활동일지", reportText.getText().toString()));
        Toast.makeText(this, "활동일지를 복사했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle("전체 초기화")
                .setMessage("현재 출동의 모든 기록을 삭제할까요?")
                .setPositiveButton("초기화", (d, w) -> {
                    events.clear();
                    trackingTransport = false;
                    transportDistanceMeters = 0f;
                    lastTransportLocation = null;
                    reportText.setText("아직 활동일지가 생성되지 않았습니다.");
                    saveState();
                    renderTimeline();
                    statusText.setText("새 출동 기록을 시작할 수 있습니다.");
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void saveState() {
        try {
            JSONArray a = new JSONArray();
            for (Event e : events) a.put(e.toJson());

            getSharedPreferences("touchlog", MODE_PRIVATE)
                    .edit()
                    .putString("events", a.toString())
                    .putFloat("distance", transportDistanceMeters)
                    .putBoolean("tracking", trackingTransport)
                    .apply();
        } catch (Exception ignored) {}
    }

    private void loadState() {
        try {
            String raw = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("events", "[]");
            transportDistanceMeters = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getFloat("distance", 0f);
            trackingTransport = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getBoolean("tracking", false);

            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                events.add(Event.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;

        if (trackingTransport && location.getAccuracy() <= 50f) {
            if (lastTransportLocation != null
                    && lastTransportLocation.getAccuracy() <= 50f) {
                float d = lastTransportLocation.distanceTo(location);
                if (d >= 2f && d <= 200f) {
                    transportDistanceMeters += d;
                }
            }
            lastTransportLocation = location;
            statusText.setText("이송 중 · "
                    + String.format(Locale.KOREA, "%.2f km", transportDistanceMeters / 1000f)
                    + " · GPS ±" + Math.round(location.getAccuracy()) + "m");
            saveState();
        }
    }

    @Override
    public void onProviderEnabled(String provider) { }

    @Override
    public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            statusText.setText("GPS가 꺼져 있습니다. 위치 기록을 위해 GPS를 켜주세요.");
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2001 && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates();
        } else {
            statusText.setText("위치 권한 없이 시간 기록만 사용할 수 있습니다.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            locationManager.removeUpdates(this);
        } catch (Exception ignored) {}
    }
}
