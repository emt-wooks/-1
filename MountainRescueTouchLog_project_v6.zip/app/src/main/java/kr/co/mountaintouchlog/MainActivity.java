package kr.co.mountaintouchlog;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {

    static class Event {
        String type;
        long time;
        double lat = Double.NaN;
        double lon = Double.NaN;
        double alt = Double.NaN;
        String note = "";

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("time", time);
            o.put("lat", lat);
            o.put("lon", lon);
            o.put("alt", alt);
            o.put("note", note);
            return o;
        }

        static Event fromJson(JSONObject o) throws Exception {
            Event e = new Event();
            e.type = o.getString("type");
            e.time = o.getLong("time");
            e.lat = o.optDouble("lat", Double.NaN);
            e.lon = o.optDouble("lon", Double.NaN);
            e.alt = o.optDouble("alt", Double.NaN);
            e.note = o.optString("note", "");
            return e;
        }
    }

    private final ArrayList<Event> events = new ArrayList<>();
    private LinearLayout eventContainer;
    private TextView statusText, reportText;

    private String patientSexAge = "";
    private String patientComplaint = "";
    private String patientCondition = "";
    private String patientVoiceNote = "";
    private String sceneType = "";
    private String sceneTerrain = "";
    private String sceneHazard = "";
    private LocationManager locationManager;
    private Location lastLocation;

    private SpeechRecognizer speechRecognizer;
    private EditText speechTarget;
    private String speechPrefix = "";
    private Location lastTransportLocation;
    private boolean trackingTransport = false;
    private float transportDistanceMeters = 0f;

    private final SimpleDateFormat timeFmt =
            new SimpleDateFormat("HH:mm:ss", Locale.KOREA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventContainer = findViewById(R.id.eventContainer);
        statusText = findViewById(R.id.statusText);
        reportText = findViewById(R.id.reportText);


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        setupSpeechRecognizer();

        findViewById(R.id.dispatchButton).setOnClickListener(v ->
                addMainEvent("구조출동", false));
        findViewById(R.id.contactButton).setOnClickListener(v -> {
            if (addMainEvent("환자접촉", false)) {
                showPostContactInfoFlow();
            }
        });
        findViewById(R.id.treatmentButton).setOnClickListener(v ->
                addTreatment());
        findViewById(R.id.transportButton).setOnClickListener(v -> {
            if (addMainEvent("이송시작", false)) startTransportTracking();
        });
        findViewById(R.id.descentButton).setOnClickListener(v -> {
            if (addMainEvent("하산완료", false)) stopTransportTracking();
        });

        findViewById(R.id.fireButton).setOnClickListener(v ->
                addMainEvent("소방 인계", true));
        findViewById(R.id.heliButton).setOnClickListener(v ->
                addMainEvent("헬기 인계", true));
        findViewById(R.id.hospitalButton).setOnClickListener(v ->
                addMainEvent("병원 이송", true));

        findViewById(R.id.reportButton).setOnClickListener(v -> buildReport());
        findViewById(R.id.reportButton).setOnLongClickListener(v -> {
            showEditBasicInfoChoice();
            return true;
        });
        findViewById(R.id.copyButton).setOnClickListener(v -> copyReport());
        findViewById(R.id.resetButton).setOnClickListener(v -> confirmReset());

        requestLocationPermission();
        loadState();
        renderTimeline();

        if (findFirst("이송시작") != null && findFirst("하산완료") == null) {
            startTransportTracking();
        }
    }


    private void setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                statusText.setText("음성인식 준비됨 · 말씀하세요.");
            }

            @Override public void onBeginningOfSpeech() {
                statusText.setText("음성인식 중...");
            }

            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                statusText.setText("음성 처리 중...");
            }

            @Override public void onError(int error) {
                statusText.setText("음성인식이 잘 되지 않았습니다. 다시 눌러 말해주세요.");
                Toast.makeText(MainActivity.this,
                        "음성인식 실패 · 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
            }

            @Override public void onResults(Bundle results) {
                ArrayList<String> list =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (list != null && !list.isEmpty() && speechTarget != null) {
                    String result = list.get(0).trim();
                    String existing = speechTarget.getText().toString().trim();

                    if (speechPrefix != null && !speechPrefix.isEmpty()) {
                        existing = speechPrefix.trim();
                    }

                    if (!existing.isEmpty()) {
                        speechTarget.setText(existing + " " + result);
                    } else {
                        speechTarget.setText(result);
                    }
                    speechTarget.setSelection(speechTarget.getText().length());
                    statusText.setText("음성입력 완료 · 필요하면 글자를 수정하세요.");
                }
                speechPrefix = "";
            }

            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startVoiceInput(EditText target) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2002);
            Toast.makeText(this,
                    "마이크 권한을 허용한 뒤 음성입력 버튼을 다시 눌러주세요.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (speechRecognizer == null) {
            setupSpeechRecognizer();
        }

        if (speechRecognizer == null) {
            Toast.makeText(this,
                    "이 기기에서 음성인식을 사용할 수 없습니다.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        speechTarget = target;
        speechPrefix = target.getText().toString();

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ko-KR");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);

        speechRecognizer.startListening(intent);
    }

    private void requestLocationPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.RECORD_AUDIO
            }, 2001);
        } else {
            startLocationUpdates();
        }
    }

    private void startLocationUpdates() {
        try {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) return;

            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 3000, 3, this);

            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (gps != null) lastLocation = gps;
        } catch (Exception ignored) {}
    }



    private void showPostContactInfoFlow() {
        showPatientDialog(true);
    }

    private void showPatientDialog(boolean continueToScene) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);

        EditText sexAge = new EditText(this);
        sexAge.setHint("성별/연령  예: 남 43세");
        sexAge.setText(patientSexAge);

        EditText complaint = new EditText(this);
        complaint.setHint("주호소·손상부위  예: 우측 발목 통증");
        complaint.setText(patientComplaint);

        EditText condition = new EditText(this);
        condition.setHint("환자상태  예: 의식 명료, 보행 불가");
        condition.setText(patientCondition);

        EditText voiceNote = new EditText(this);
        voiceNote.setHint("환자정보 음성기록  예: 남자 43세, 우측 발목 통증과 부종...");
        voiceNote.setMinLines(3);
        voiceNote.setText(patientVoiceNote);

        Button voiceButton = new Button(this);
        voiceButton.setText("🎙 환자정보 음성입력");
        voiceButton.setOnClickListener(v -> startVoiceInput(voiceNote));

        box.addView(sexAge);
        box.addView(complaint);
        box.addView(condition);
        box.addView(voiceButton);
        box.addView(voiceNote);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("환자정보")
                .setView(box)
                .setPositiveButton("저장 후 다음", null)
                .setNeutralButton("나중에", null)
                .setNegativeButton("취소", null)
                .create();

        dialog.setOnShowListener(x -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                patientSexAge = sexAge.getText().toString().trim();
                patientComplaint = complaint.getText().toString().trim();
                patientCondition = condition.getText().toString().trim();
                saveState();
                dialog.dismiss();
                if (continueToScene) showSceneDialog(false);
            });

            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                patientSexAge = sexAge.getText().toString().trim();
                patientComplaint = complaint.getText().toString().trim();
                patientCondition = condition.getText().toString().trim();
                patientVoiceNote = voiceNote.getText().toString().trim();
                saveState();
                dialog.dismiss();
                if (continueToScene) showSceneDialog(false);
            });
        });

        dialog.show();
    }

    private void showSceneDialog(boolean standalone) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);

        EditText type = new EditText(this);
        type.setHint("사고유형  예: 산행 중 낙상");
        type.setText(sceneType);

        EditText terrain = new EditText(this);
        terrain.setHint("현장·지형  예: 급경사 암릉, 탐방로 이탈 30m");
        terrain.setText(sceneTerrain);

        EditText hazard = new EditText(this);
        hazard.setHint("위험요인·특이사항  예: 낙석 위험, 우천, 야간");
        hazard.setText(sceneHazard);

        box.addView(type);
        box.addView(terrain);
        box.addView(hazard);

        new AlertDialog.Builder(this)
                .setTitle("현장상황")
                .setView(box)
                .setPositiveButton("저장", (d, w) -> {
                    sceneType = type.getText().toString().trim();
                    sceneTerrain = terrain.getText().toString().trim();
                    sceneHazard = hazard.getText().toString().trim();
                    saveState();
                })
                .setNeutralButton("나중에", null)
                .setNegativeButton("취소", null)
                .show();
    }

    private void showEditBasicInfoChoice() {
        String[] items = {"환자정보 수정", "현장상황 수정"};
        new AlertDialog.Builder(this)
                .setTitle("환자·현장정보 수정")
                .setItems(items, (d, which) -> {
                    if (which == 0) showPatientDialog(false);
                    else showSceneDialog(true);
                })
                .show();
    }

    private boolean addMainEvent(String type, boolean allowDuplicate) {
        if (!allowDuplicate && findFirst(type) != null) {
            Toast.makeText(this, type + " 기록이 이미 있습니다.", Toast.LENGTH_SHORT).show();
            return false;
        }

        Event e = new Event();
        e.type = type;
        e.time = System.currentTimeMillis();
        applyCurrentLocation(e);
        events.add(e);
        saveState();
        renderTimeline();

        statusText.setText(type + " 기록 완료 · " + timeFmt.format(new Date(e.time)));
        return true;
    }

    private void addTreatment() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);

        final EditText input = new EditText(this);
        input.setHint("예: 우측 발목 부종 및 압통 확인, SAM splint 적용");
        input.setMinLines(4);

        Button voiceButton = new Button(this);
        voiceButton.setText("🎙 처치내용 음성입력");
        voiceButton.setOnClickListener(v -> startVoiceInput(input));

        box.addView(voiceButton);
        box.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("처치 기록")
                .setView(box)
                .setPositiveButton("기록", (d, w) -> {
                    Event e = new Event();
                    e.type = "처치";
                    e.time = System.currentTimeMillis();
                    e.note = input.getText().toString().trim();
                    applyCurrentLocation(e);
                    events.add(e);
                    saveState();
                    renderTimeline();
                    statusText.setText("처치 기록 완료 · " + timeFmt.format(new Date(e.time)));
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void applyCurrentLocation(Event e) {
        Location l = lastLocation;
        if (l != null) {
            e.lat = l.getLatitude();
            e.lon = l.getLongitude();
            if (l.hasAltitude()) e.alt = l.getAltitude();
        }
    }

    private void renderTimeline() {
        eventContainer.removeAllViews();

        if (events.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("\n아직 기록이 없습니다.");
            eventContainer.addView(empty);
            return;
        }

        for (int i = 0; i < events.size(); i++) {
            final int idx = i;
            Event e = events.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 8, 0, 8);

            TextView t = new TextView(this);
            t.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            t.setText(formatEvent(e));
            t.setTextSize(14);

            Button edit = new Button(this);
            edit.setText("수정");
            edit.setOnClickListener(v -> editEvent(idx));

            Button del = new Button(this);
            del.setText("삭제");
            del.setOnClickListener(v -> deleteEvent(idx));

            row.addView(t);
            row.addView(edit);
            row.addView(del);
            eventContainer.addView(row);
        }
    }

    private String formatEvent(Event e) {
        StringBuilder sb = new StringBuilder();
        sb.append(timeFmt.format(new Date(e.time))).append("  ").append(e.type);
        if (!e.note.isEmpty()) sb.append("\n").append(e.note);
        if (!Double.isNaN(e.lat)) {
            sb.append(String.format(Locale.KOREA,
                    "\nGPS %.5f, %.5f", e.lat, e.lon));
        }
        if (!Double.isNaN(e.alt)) {
            sb.append(String.format(Locale.KOREA, " · 고도 %.0fm", e.alt));
        }
        return sb.toString();
    }

    private void editEvent(int idx) {
        Event e = events.get(idx);
        final EditText input = new EditText(this);
        input.setText(e.note);
        input.setHint("메모 수정");

        new AlertDialog.Builder(this)
                .setTitle(e.type + " 메모 수정")
                .setView(input)
                .setPositiveButton("저장", (d, w) -> {
                    e.note = input.getText().toString().trim();
                    saveState();
                    renderTimeline();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void deleteEvent(int idx) {
        Event e = events.get(idx);
        new AlertDialog.Builder(this)
                .setTitle("기록 삭제")
                .setMessage(timeFmt.format(new Date(e.time)) + " " + e.type + " 기록을 삭제할까요?")
                .setPositiveButton("삭제", (d, w) -> {
                    events.remove(idx);
                    if ("이송시작".equals(e.type) || "하산완료".equals(e.type)) {
                        recalcTransportState();
                    }
                    saveState();
                    renderTimeline();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void startTransportTracking() {
        trackingTransport = true;
        lastTransportLocation = lastLocation;
        statusText.setText("이송 중 · GPS 이동거리 누적 중");
        saveState();
    }

    private void stopTransportTracking() {
        trackingTransport = false;
        lastTransportLocation = null;
        statusText.setText("하산완료 · 이송거리 "
                + String.format(Locale.KOREA, "%.2f km", transportDistanceMeters / 1000f));
        saveState();
    }

    private void recalcTransportState() {
        Event start = findFirst("이송시작");
        Event end = findFirst("하산완료");
        trackingTransport = start != null && end == null;
        if (start == null) transportDistanceMeters = 0f;
        lastTransportLocation = trackingTransport ? lastLocation : null;
    }

    private Event findFirst(String type) {
        for (Event e : events) {
            if (type.equals(e.type)) return e;
        }
        return null;
    }

    private ArrayList<Event> findAll(String type) {
        ArrayList<Event> out = new ArrayList<>();
        for (Event e : events) if (type.equals(e.type)) out.add(e);
        return out;
    }

    private void buildReport() {
        Event dispatch = findFirst("구조출동");
        Event contact = findFirst("환자접촉");
        Event start = findFirst("이송시작");
        Event descent = findFirst("하산완료");
        ArrayList<Event> treatments = findAll("처치");

        StringBuilder s = new StringBuilder();

        if (!patientSexAge.isEmpty() || !patientComplaint.isEmpty()
                || !patientCondition.isEmpty() || !patientVoiceNote.isEmpty()) {
            s.append("[환자정보]");
            if (!patientSexAge.isEmpty()) s.append("\n- 성별/연령: ").append(patientSexAge);
            if (!patientComplaint.isEmpty()) s.append("\n- 주호소/손상: ").append(patientComplaint);
            if (!patientCondition.isEmpty()) s.append("\n- 상태: ").append(patientCondition);
            if (!patientVoiceNote.isEmpty()) s.append("\n- 환자접촉 음성기록: ").append(patientVoiceNote);
            s.append("\n\n");
        }

        if (!sceneType.isEmpty() || !sceneTerrain.isEmpty() || !sceneHazard.isEmpty()) {
            s.append("[현장상황]");
            if (!sceneType.isEmpty()) s.append("\n- 사고유형: ").append(sceneType);
            if (!sceneTerrain.isEmpty()) s.append("\n- 현장/지형: ").append(sceneTerrain);
            if (!sceneHazard.isEmpty()) s.append("\n- 위험요인: ").append(sceneHazard);
            s.append("\n\n");
        }

        s.append("[활동기록]\n");

        if (dispatch != null) {
            s.append(timeFmt.format(new Date(dispatch.time)))
                    .append(" 구조출동.");
        }

        if (contact != null) {
            if (s.length() > 0) s.append(" ");
            s.append(timeFmt.format(new Date(contact.time)))
                    .append(" 요구조자 접촉.");
        }

        for (Event e : treatments) {
            s.append(" ").append(timeFmt.format(new Date(e.time)))
                    .append(" 응급처치 실시");
            if (!e.note.isEmpty()) s.append(": ").append(e.note);
            s.append(".");
        }

        if (start != null) {
            s.append(" ").append(timeFmt.format(new Date(start.time)))
                    .append(" 이송 시작.");
        }

        if (descent != null) {
            s.append(" ").append(timeFmt.format(new Date(descent.time)))
                    .append(" 하산 완료.");
        }

        for (Event e : events) {
            if ("소방 인계".equals(e.type) || "헬기 인계".equals(e.type)
                    || "병원 이송".equals(e.type)) {
                s.append(" ").append(timeFmt.format(new Date(e.time)))
                        .append(" ").append(e.type).append(".");
            }
        }

        s.append("\n\n[자동 계산]");
        if (dispatch != null && descent != null) {
            s.append("\n총 출동시간: ").append(formatDuration(descent.time - dispatch.time));
        }
        if (dispatch != null && contact != null) {
            s.append("\n구조출동→환자접촉: ")
                    .append(formatDuration(contact.time - dispatch.time));
        }
        if (contact != null && descent != null) {
            s.append("\n환자접촉→하산완료: ")
                    .append(formatDuration(descent.time - contact.time));
        }
        if (contact != null && !treatments.isEmpty()) {
            s.append("\n환자접촉→첫 처치: ")
                    .append(formatDuration(treatments.get(0).time - contact.time));
        }
        if (start != null && descent != null) {
            s.append("\n이송 소요시간: ")
                    .append(formatDuration(descent.time - start.time));
        }
        if (transportDistanceMeters > 0) {
            s.append(String.format(Locale.KOREA,
                    "\nGPS 누적 이송거리: %.2f km", transportDistanceMeters / 1000f));
        }
        if (start != null && descent != null
                && !Double.isNaN(start.alt) && !Double.isNaN(descent.alt)) {
            s.append(String.format(Locale.KOREA,
                    "\n이송 시작→하산완료 고도차: %.0f m", descent.alt - start.alt));
        }

        reportText.setText(s.length() > 0 ? s.toString()
                : "기록된 활동이 없습니다.");
    }

    private String formatDuration(long ms) {
        long sec = Math.max(0, ms / 1000);
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long ss = sec % 60;
        if (h > 0) return String.format(Locale.KOREA, "%d시간 %d분 %d초", h, m, ss);
        return String.format(Locale.KOREA, "%d분 %d초", m, ss);
    }

    private void copyReport() {
        ClipboardManager cm =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(
                "산악구조 활동일지", reportText.getText().toString()));
        Toast.makeText(this, "활동일지를 복사했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle("전체 초기화")
                .setMessage("현재 출동의 모든 기록을 삭제할까요?")
                .setPositiveButton("초기화", (d, w) -> {
                    events.clear();
                    patientSexAge = "";
                    patientComplaint = "";
                    patientCondition = "";
                    patientVoiceNote = "";
                    sceneType = "";
                    sceneTerrain = "";
                    sceneHazard = "";
                    trackingTransport = false;
                    transportDistanceMeters = 0f;
                    lastTransportLocation = null;
                    reportText.setText("아직 활동일지가 생성되지 않았습니다.");
                    saveState();
                    renderTimeline();
                    statusText.setText("새 출동 기록을 시작할 수 있습니다.");
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void saveState() {
        try {
            JSONArray a = new JSONArray();
            for (Event e : events) a.put(e.toJson());

            getSharedPreferences("touchlog", MODE_PRIVATE)
                    .edit()
                    .putString("events", a.toString())
                    .putFloat("distance", transportDistanceMeters)
                    .putBoolean("tracking", trackingTransport)
                    .putString("patientSexAge", patientSexAge)
                    .putString("patientComplaint", patientComplaint)
                    .putString("patientCondition", patientCondition)
                    .putString("patientVoiceNote", patientVoiceNote)
                    .putString("sceneType", sceneType)
                    .putString("sceneTerrain", sceneTerrain)
                    .putString("sceneHazard", sceneHazard)
                    .apply();
        } catch (Exception ignored) {}
    }

    private void loadState() {
        try {
            String raw = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("events", "[]");
            transportDistanceMeters = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getFloat("distance", 0f);
            trackingTransport = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getBoolean("tracking", false);
            patientSexAge = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("patientSexAge", "");
            patientComplaint = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("patientComplaint", "");
            patientCondition = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("patientCondition", "");
            patientVoiceNote = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("patientVoiceNote", "");
            sceneType = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("sceneType", "");
            sceneTerrain = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("sceneTerrain", "");
            sceneHazard = getSharedPreferences("touchlog", MODE_PRIVATE)
                    .getString("sceneHazard", "");

            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                events.add(Event.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;

        if (trackingTransport && location.getAccuracy() <= 50f) {
            if (lastTransportLocation != null
                    && lastTransportLocation.getAccuracy() <= 50f) {
                float d = lastTransportLocation.distanceTo(location);
                if (d >= 2f && d <= 200f) {
                    transportDistanceMeters += d;
                }
            }
            lastTransportLocation = location;
            statusText.setText("이송 중 · "
                    + String.format(Locale.KOREA, "%.2f km", transportDistanceMeters / 1000f)
                    + " · GPS ±" + Math.round(location.getAccuracy()) + "m");
            saveState();
        }
    }

    @Override
    public void onProviderEnabled(String provider) { }

    @Override
    public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            statusText.setText("GPS가 꺼져 있습니다. 위치 기록을 위해 GPS를 켜주세요.");
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2001 && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates();
        } else {
            statusText.setText("위치 권한 없이 시간 기록만 사용할 수 있습니다.");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            locationManager.removeUpdates(this);
        } catch (Exception ignored) {}

        try {
            if (speechRecognizer != null) {
                speechRecognizer.destroy();
            }
        } catch (Exception ignored) {}
    }
}
